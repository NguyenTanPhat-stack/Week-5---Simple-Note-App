class GhiChu {
  String cauHoi;
  String cauTraLoi;

  GhiChu({
    required this.cauHoi,
    required this.cauTraLoi,
  });
}
